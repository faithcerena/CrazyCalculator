public class Link {

  String string;
  Link next;
  public Link(String string){
    this.string = string;
  }

  public String toString(){
    return string;
  }
}
